
package ParkingSystem;


public class JavaApplication6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        new Selector().setVisible(true);
    }
}
